package il.cshaifasweng.OCSFMediatorExample.client;

public class Main {

	public static void main(String[] args) {
		SimpleChatClient.main(args);
	}

}
